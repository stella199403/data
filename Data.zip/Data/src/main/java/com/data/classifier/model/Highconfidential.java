package com.data.classifier.model;

public class Highconfidential
{
    private String employeeid;
    private String firstname;
    private String lastname;
    private String email;
    private String dob;
    private String tob;
    private String ageinyears;
    private String dateofjoining;
    private String yearofjoining;
    private String shortmonth;
    private String ageincompany;
    private String salary;
    private String lastpercentagehike;
    private String ssn;
    private String phone;
    private String username;
    private String password;

    public String getEmployeeid()
    {
        return employeeid;
    }

    public void setEmployeeid(String employeeid)
    {
        this.employeeid = employeeid;
    }

    public String getFirstname()
    {
        return firstname;
    }

    public void setFirstname(String firstname)
    {
        this.firstname = firstname;
    }

    public String getLastname()
    {
        return lastname;
    }

    public void setLastname(String lastname)
    {
        this.lastname = lastname;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getDob()
    {
        return dob;
    }

    public void setDob(String dob)
    {
        this.dob = dob;
    }

    public String getTob()
    {
        return tob;
    }

    public void setTob(String tob)
    {
        this.tob = tob;
    }

    public String getAgeinyears()
    {
        return ageinyears;
    }

    public void setAgeinyears(String ageinyears)
    {
        this.ageinyears = ageinyears;
    }

    public String getDateofjoining()
    {
        return dateofjoining;
    }

    public void setDateofjoining(String dateofjoining)
    {
        this.dateofjoining = dateofjoining;
    }

    public String getYearofjoining()
    {
        return yearofjoining;
    }

    public void setYearofjoining(String yearofjoining)
    {
        this.yearofjoining = yearofjoining;
    }

    public String getShortmonth()
    {
        return shortmonth;
    }

    public void setShortmonth(String shortmonth)
    {
        this.shortmonth = shortmonth;
    }

    public String getAgeincompany()
    {
        return ageincompany;
    }

    public void setAgeincompany(String ageincompany)
    {
        this.ageincompany = ageincompany;
    }

    public String getSalary()
    {
        return salary;
    }

    public void setSalary(String salary)
    {
        this.salary = salary;
    }

    public String getLastpercentagehike()
    {
        return lastpercentagehike;
    }

    public void setLastpercentagehike(String lastpercentagehike)
    {
        this.lastpercentagehike = lastpercentagehike;
    }

    public String getSsn()
    {
        return ssn;
    }

    public void setSsn(String ssn)
    {
        this.ssn = ssn;
    }

    public String getPhone()
    {
        return phone;
    }

    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public String getPassword()
    {
        return password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

}
